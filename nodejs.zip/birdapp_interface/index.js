if (process.env.NODE_ENV !== "production") {
    require(`dotenv`).config();
  }
  
  const express = require(`express`);
  const app = express();
  const passport = require(`passport`);
  const flash = require(`express-flash`);
  const session = require("express-session");
  const methodOverride = require("method-override");
  const cors = require("cors");
  const bodyParser = require("body-parser");
  const multer = require("multer");
  const birdList = require("./controllers/conBirdlist");
  const surveyList = require("./controllers/conSurveyList");
  
  
  var upload = multer({ dest: "uploads/" });
  const user = [{}];
  

  
  // initializePassport(
  //   passport,
  //   (email) => fetchUser(email),
  //   (userID) => getUserByID(userID)
  // );
  
  app.set("view-engine", "jsx");
  app.use(cors());
  app.use(express.urlencoded({ extended: false }));
  app.use(flash());
  app.use(
    session({
      secret: process.env.SESSION_SECRET,
      resave: false,
      saveUninitialized: false,
    })
  );
  app.use(bodyParser.urlencoded({ extended: true }));
  app.use(bodyParser.json());
  app.use(passport.initialize());
  app.use(passport.session());
  app.use(methodOverride("_method"));
  /************************************************************************* */
  
  
  //getfullbirdlist
  app.get("/birdlist", birdList.getAll, (req, res) => {});
  
  /************************************************************************* */
  //POST
  /************************************************************************* */
  app.post("/uploadBirdList", surveyList.post, (req, res)=> {});


  app.listen(9003);
  console.log(`listening to 9003`)