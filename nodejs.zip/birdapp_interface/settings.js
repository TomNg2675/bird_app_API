exports.dbConfig = {
    user: "sa",
    password: "Sqllite37213721",
    server: "DESKTOP-OMSE51K\\TOMNG",
    database: "BirdList",
    port: 1433,
    options: {
        enableArithAbort: true
    }
};