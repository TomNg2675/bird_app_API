var db = require("../db");
var sqlDb = require("mssql");
var settings = require("../settings");

exports.getAll = function (req, res, next) {
  console.log("getBirdList");
  db.executeSql(`select * from hkBird_import;`, function (data, err) {
    if (err) {
      res.status(500).send("Intenal Error");
    } else {
      res.status(200).json(data.recordsets[0]);
    }
  });
};