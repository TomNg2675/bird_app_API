var sqlDb = require("mssql");
var settings = require("../settings");

exports.post = function (req, res, next) {
  console.log(`created new list ${req.ip}`);

  const userID = req.body.userID;
  const createdTime = req.body.createdTime;
  const surveyList = req.body.surveyList;

  console.log(`userID: ${userID}, createTime: ${createdTime}`);
  const sl = JSON.stringify(req.body)

  var conn = new sqlDb.ConnectionPool(settings.dbConfig);
  conn.connect(function (err) {
    if (err) return res.sendStatus(500);
    var request = conn.request();
    var query = `
    DECLARE @json nvarchar(max)
    declare @userID int
    declare @createdTime datetime2
    set @userID = ${userID}
    set @createdTime = '${createdTime}'
    SET @json = '${sl}'
        
    BEGIN TRANSACTION
        DECLARE @DataID int;
        INSERT INTO SurveyHeader (userID, createdTime) VALUES (@userID, @createdTime);

        insert into Survey (survey_headerID, birdID,long,lat, recordTime,[status],activity,[image],[video],[count])
        SELECT SCOPE_IDENTITY() as survey_headerID, a.[birdID], a.[long], a.[lat], a.[recordTime], a.[image], a.[video], a.[birdStatus], a.[birdActivity],a.[count]
        FROM OPENJSON(@json) WITH (
            surveyList nvarchar(max) '$.surveyList' AS JSON
        ) AS i
        CROSS APPLY OPENJSON(i.surveyList) WITH (
            [birdID] int '$.birdID',
            [long] float '$.long',
            [lat] float '$.lat',
            [recordTime] datetime2 '$.recordTime' ,
            [birdStatus] nvarchar(40) '$.birdStatus' ,
            [birdActivity] nvarchar(40) '$.birdActivity',
            [image] nvarchar(max) '$.image',
            [video] nvarchar(max) '$.video',
            [count] int '$.count'
        ) a;
    COMMIT;`;
      request.query(query,(err, result) => {
          if (err) {console.log(err); return res.sendStatus(500)};
          console.log(`Number of records inserted: ${result.rowsAffected}`);
          return res.sendStatus(200);
        }
      );
  });
};
